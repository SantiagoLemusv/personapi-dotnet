db = db.getSiblingDB('personadb');

db.persons.insertOne({
  _id: NumberLong(1234567890),
  nombre: "Juan",
  apellido: "Perez",
  genero: "M",
  edad: 25
});
