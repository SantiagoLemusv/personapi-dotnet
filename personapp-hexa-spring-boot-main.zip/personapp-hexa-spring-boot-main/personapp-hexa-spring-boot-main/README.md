Perfecto, aquí tienes un README listo para tu release en GitHub, \*\*explicativo y profesional\*\* pero también rápido de pegar:



---



\# PersonAPP Hexagonal – Release v0.0.1



\*\*Descripción:\*\*

Este release incluye todos los módulos del proyecto PersonAPP implementado con arquitectura hexagonal (Clean Architecture). Contiene el código fuente de los módulos principales y adaptadores:



\* `common`

\* `domain`

\* `application`

\* `maria-output-adapter`

\* `mongo-output-adapter`

\* `rest-input-adapter`

\* `cli-input-adapter`



El objetivo es permitir que cualquier usuario clone y compile el proyecto localmente.



---



\## \*\*Contenido del release\*\*



\* Código fuente completo de todos los módulos.

\* Archivos `pom.xml` para Maven multi-módulo.

\* JAR compilado del módulo `rest-input-adapter` (`target/rest-input-adapter-0.0.1-SNAPSHOT.jar`).



⚠️ \*\*Nota importante:\*\* El JAR compilado no es ejecutable directamente debido a configuración de Spring Boot pendiente. Se recomienda compilar desde el código fuente.



---



\## \*\*Requisitos\*\*



\* Java 11 (OpenJDK o Oracle JDK)

\* Maven 3.x

\* Conexión a base de datos MariaDB o MongoDB si se van a probar los adaptadores correspondientes



---



\## \*\*Cómo compilar y ejecutar\*\*



1\. Clonar el repositorio:



```bash

git clone <REPO\_URL>

cd personapp-hexa-spring-boot-main

```



2\. Construir todos los módulos:



```bash

mvn clean package

```



3\. Ejecutar el módulo REST Input Adapter:



```bash

java -jar rest-input-adapter/target/rest-input-adapter-0.0.1-SNAPSHOT.jar

```



> ⚠️ Recuerda: La clase principal `RestInputAdapterApplication` debe estar correctamente configurada en `pom.xml`.



---



\## \*\*Notas de release\*\*



\* Este release está pensado como \*\*punto inicial\*\* para compilación y pruebas locales.

\* Para futuras versiones se incluirá un \*\*JAR ejecutable listo\*\* y configuración de dependencias finalizadas.

\* Tags y versiones futuras seguirán el esquema `v<major>.<minor>.<patch>`.



---



\## \*\*Desarrollador\*\*



\* Santiago Lemus – \[Pontificia Universidad Javeriana](https://www.javeriana.edu.co)



---



