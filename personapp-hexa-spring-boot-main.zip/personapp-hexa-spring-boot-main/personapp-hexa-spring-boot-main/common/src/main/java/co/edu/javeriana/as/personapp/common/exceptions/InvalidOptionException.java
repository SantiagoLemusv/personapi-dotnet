package co.edu.javeriana.as.personapp.common.exceptions;

public class InvalidOptionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public InvalidOptionException(String mensaje) {
		super(mensaje);
	}

}
