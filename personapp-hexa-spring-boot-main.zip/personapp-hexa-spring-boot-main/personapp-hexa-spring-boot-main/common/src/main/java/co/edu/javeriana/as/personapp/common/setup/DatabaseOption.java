package co.edu.javeriana.as.personapp.common.setup;

public enum DatabaseOption {
	MONGO, MARIA
}
