-- schema.sql
CREATE DATABASE IF NOT EXISTS persona_db;
USE persona_db;

CREATE TABLE IF NOT EXISTS profesion (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nom VARCHAR(90) NOT NULL,
  des TEXT
);

CREATE TABLE IF NOT EXISTS persona (
  cc BIGINT PRIMARY KEY,
  nombre VARCHAR(45),
  apellido VARCHAR(45),
  genero ENUM('M','F'),
  edad INT
);

CREATE TABLE IF NOT EXISTS estudios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  cc_per BIGINT NOT NULL,
  fecha DATE,
  univer VARCHAR(50),
  CONSTRAINT fk_estudio_persona FOREIGN KEY (cc_per) REFERENCES persona(cc) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS telefono (
  num BIGINT PRIMARY KEY,
  oper VARCHAR(45),
  duenio BIGINT,
  CONSTRAINT fk_telefono_persona FOREIGN KEY (duenio) REFERENCES persona(cc) ON DELETE CASCADE
);

-- Seed data
INSERT INTO profesion (nom, des) VALUES ('Ingeniero', 'Ingenieria de sistemas') ON DUPLICATE KEY UPDATE nom=nom;
INSERT INTO persona (cc, nombre, apellido, genero, edad) VALUES (1234567890, 'Juan', 'Perez', 'M', 25) ON DUPLICATE KEY UPDATE nombre=nombre;
INSERT INTO estudios (cc_per, fecha, univer) VALUES (1234567890, '2020-06-01', 'Universidad X');
INSERT INTO telefono (num, oper, duenio) VALUES (3001112222, 'TIGO', 1234567890);
