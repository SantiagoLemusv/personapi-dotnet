package co.edu.javeriana.as.personapp.domain;

public enum Gender {
	MALE, FEMALE, OTHER
}
